import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:simple_animations/simple_animations.dart';

const Color lightColor = Color.fromARGB(255, 37, 153, 68);
const Color mediumColor = Color.fromARGB(255, 3, 102, 29);
const Color darkColor = Color.fromARGB(255, 0, 47, 13);
const Color mainTextColor = Colors.white;
const Color backgroundColor = Colors.white;
const Color shadowColor = mediumColor;
const Color borderColor = Colors.grey;

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [lightColor, mediumColor, darkColor],
          ),
        ),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              SizedBox(height: screenHeight * 0.05),
              Padding(
                padding: EdgeInsets.all(screenWidth * 0.02),
                child: const HeaderSection(),
              ),
              SizedBox(height: screenHeight * 0.02),
              const ContentSection(),
            ],
          ),
        ),
      ),
    );
  }
}

class HeaderSection extends StatelessWidget {
  const HeaderSection({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          "Logowanie",
          style: TextStyle(
            color: mainTextColor,
            fontSize: screenWidth * 0.035, // mniejsza czcionka
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: screenWidth * 0.003),
        Text(
          "Witajmy z powrotem",
          style: TextStyle(
            color: mainTextColor,
            fontSize: screenWidth * 0.018, // mniejsza czcionka
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }
}

class ContentSection extends StatefulWidget {
  const ContentSection({super.key});

  @override
  State<ContentSection> createState() => _ContentSectionState();
}

class _ContentSectionState extends State<ContentSection> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      decoration: const BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(40),
          topRight: Radius.circular(40),
        ),
      ),
      child: Column(
        children: <Widget>[
          SizedBox(height: screenHeight * 0.02),
          LoginForm(
            emailController: emailController,
            passwordController: passwordController,
          ),
          SizedBox(height: screenHeight * 0.02),
          Text(
            "Zapomniałeś hasła?",
            style: TextStyle(color: borderColor, fontSize: screenWidth * 0.018),
          ),
          SizedBox(height: screenHeight * 0.02),
          LoginButton(
            emailController: emailController,
            passwordController: passwordController,
          ),
          SizedBox(height: screenHeight * 0.04),
          Text(
            "Nie masz konta? Zarejestruj się",
            style: TextStyle(color: borderColor, fontSize: screenWidth * 0.018),
          ),
        ],
      ),
    );
  }
}

class LoginForm extends StatelessWidget {
  final TextEditingController emailController;
  final TextEditingController passwordController;

  const LoginForm({
    super.key,
    required this.emailController,
    required this.passwordController,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      margin: EdgeInsets.symmetric(horizontal: screenWidth * 0.02),
      padding: EdgeInsets.all(screenWidth * 0.02),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(40),
        boxShadow: [
          BoxShadow(
            color: shadowColor.withAlpha(50),
            blurRadius: screenWidth * 0.01,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: <Widget>[
          _LoginTextField(
            controller: emailController,
            hintText: "Email",
            obscure: false,
          ),
          _LoginTextField(
            controller: passwordController,
            hintText: "Hasło",
            obscure: true,
          ),
        ],
      ),
    );
  }
}

class _LoginTextField extends StatelessWidget {
  final String hintText;
  final bool obscure;
  final TextEditingController controller;

  const _LoginTextField({
    required this.hintText,
    required this.obscure,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Container(
      padding: EdgeInsets.all(screenWidth * 0.012),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: borderColor)),
      ),
      child: TextField(
        controller: controller,
        obscureText: obscure,
        decoration: InputDecoration(
          hintText: hintText,
          hintStyle: TextStyle(
            color: borderColor,
            fontSize: screenWidth * 0.018,
          ),
          border: InputBorder.none,
        ),
      ),
    );
  }
}

class LoginButton extends StatelessWidget {
  final TextEditingController emailController;
  final TextEditingController passwordController;

  const LoginButton({
    super.key,
    required this.emailController,
    required this.passwordController,
  });

  Future<void> login(BuildContext context) async {
    final url = Uri.parse("http://127.0.0.1:8000/api-token-auth/");
    final response = await http.post(
      url,
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "username": emailController.text, // albo "email", zależnie od backendu
        "password": passwordController.text,
      }),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final token = data['token']; // Django REST Framework zwraca token
      print("Zalogowano! Token: $token");

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Zalogowano pomyślnie ✅")));
    } else {
      print("Błąd logowania: ${response.body}");
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text("Błąd logowania ❌")));
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return GestureDetector(
      onTap: () => login(context),
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: screenWidth * 0.015,
          horizontal: screenWidth * 0.04,
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: darkColor,
        ),
        child: Center(
          child: Text(
            "Zaloguj się",
            style: TextStyle(
              color: mainTextColor,
              fontWeight: FontWeight.bold,
              fontSize: screenWidth * 0.022,
            ),
          ),
        ),
      ),
    );
  }
}
